export interface Project {
  id: string;
  title: string;
  description: string;
  short_description: string;
  image_url?: string;
  client?: string;
  completion_date?: string;
  category: string;
  featured: boolean;
  display_order: number;
  created_at: string;
}

export interface TeamMember {
  id: string;
  name: string;
  position: string;
  bio: string;
  image_url?: string;
  email?: string;
  linkedin_url?: string;
  display_order: number;
  created_at: string;
}

export interface Client {
  id: string;
  name: string;
  logo_url?: string;
  website_url?: string;
  display_order: number;
  created_at: string;
}

export interface Testimonial {
  id: string;
  client_name: string;
  client_position: string;
  company: string;
  content: string;
  image_url?: string;
  rating: number;
  featured: boolean;
  display_order: number;
  created_at: string;
}

export interface ContactSubmission {
  name: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
}
