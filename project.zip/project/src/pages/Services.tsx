import {
  Settings,
  Clipboard,
  PenTool,
  HardHat,
  BarChart3,
  FileCheck,
  Wrench,
  Building2,
  Zap,
  Cog,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';
import { Link } from 'react-router-dom';

export function Services() {
  const mainServices = [
    {
      icon: Settings,
      title: 'Engineering Consulting & Technical Support',
      description:
        'Expert guidance and technical assistance for complex engineering challenges across multiple disciplines.',
      features: [
        'Process optimization and efficiency analysis',
        'Technical feasibility studies',
        'Root cause analysis and troubleshooting',
        'Equipment selection and specification',
        'Compliance and regulatory support',
        'Technical training and knowledge transfer',
      ],
    },
    {
      icon: Clipboard,
      title: 'Project Planning & Management',
      description:
        'Comprehensive project oversight from initial concept through successful completion and handover.',
      features: [
        'Project scope definition and planning',
        'Resource allocation and scheduling',
        'Budget management and cost control',
        'Risk assessment and mitigation',
        'Quality assurance and control',
        'Stakeholder communication and reporting',
      ],
    },
    {
      icon: PenTool,
      title: 'Design & Analysis Services',
      description:
        'Advanced engineering design solutions utilizing the latest software tools and methodologies.',
      features: [
        'Conceptual and detailed engineering design',
        'CAD modeling and drafting (2D/3D)',
        'Finite Element Analysis (FEA)',
        'Computational Fluid Dynamics (CFD)',
        'Structural and thermal analysis',
        'Design optimization and validation',
      ],
    },
    {
      icon: HardHat,
      title: 'Site & Field Engineering',
      description:
        'On-site technical expertise ensuring smooth execution and quality installation.',
      features: [
        'Site supervision and inspection',
        'Installation support and commissioning',
        'Quality control and testing',
        'As-built documentation',
        'Troubleshooting and problem resolution',
        'Site safety management',
      ],
    },
  ];

  const specializedServices = [
    {
      icon: BarChart3,
      title: 'Performance Analysis',
      description: 'Detailed evaluation of system performance and efficiency metrics',
    },
    {
      icon: FileCheck,
      title: 'Compliance & Auditing',
      description: 'Ensuring adherence to industry standards and regulatory requirements',
    },
    {
      icon: Wrench,
      title: 'Maintenance Planning',
      description: 'Strategic maintenance programs to maximize asset lifecycle',
    },
    {
      icon: Building2,
      title: 'Facility Engineering',
      description: 'Comprehensive facility design and infrastructure solutions',
    },
    {
      icon: Zap,
      title: 'Energy Solutions',
      description: 'Energy efficiency assessments and sustainable system design',
    },
    {
      icon: Cog,
      title: 'Process Engineering',
      description: 'Industrial process design, optimization, and automation',
    },
  ];

  const industries = [
    'Oil & Gas',
    'Manufacturing',
    'Power Generation',
    'Chemical & Petrochemical',
    'Mining & Minerals',
    'Water & Wastewater',
    'Construction',
    'Transportation',
  ];

  return (
    <div className="bg-white">
      <section className="relative bg-gradient-to-br from-blue-900 to-blue-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
            <p className="text-xl text-blue-100 leading-relaxed">
              Comprehensive engineering solutions tailored to meet the unique demands of your projects and industry.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Core Service Offerings
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              End-to-end engineering solutions delivered by experienced professionals
            </p>
          </div>

          <div className="space-y-12">
            {mainServices.map((service, index) => (
              <div
                key={index}
                className={`flex flex-col lg:flex-row gap-8 items-start ${
                  index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                }`}
              >
                <div className="lg:w-1/3">
                  <div className="bg-blue-50 p-8 rounded-2xl border-l-4 border-blue-600">
                    <div className="bg-blue-600 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                      <service.icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">
                      {service.title}
                    </h3>
                    <p className="text-gray-700 leading-relaxed">{service.description}</p>
                  </div>
                </div>

                <div className="lg:w-2/3">
                  <div className="bg-gray-50 p-8 rounded-2xl">
                    <h4 className="text-xl font-semibold text-gray-900 mb-6">
                      Key Capabilities
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {service.features.map((feature, idx) => (
                        <div key={idx} className="flex items-start space-x-3">
                          <CheckCircle2 className="h-6 w-6 text-green-500 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Specialized Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Additional expertise to complement your engineering needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {specializedServices.map((service, index) => (
              <div
                key={index}
                className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow"
              >
                <div className="bg-blue-100 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                  <service.icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {service.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Industries We Serve
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12">
              Diverse sector experience delivering specialized solutions
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {industries.map((industry, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg text-center hover:shadow-md transition-shadow"
              >
                <p className="font-semibold text-gray-900">{industry}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-blue-900 to-blue-700 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Need a Customized Solution?
          </h2>
          <p className="text-xl text-blue-100 mb-8 leading-relaxed">
            We understand that every project is unique. Let's discuss how we can tailor our services to meet your specific requirements.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center px-8 py-4 bg-white text-blue-900 font-semibold rounded-lg hover:bg-blue-50 transition-colors"
          >
            Get in Touch
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
