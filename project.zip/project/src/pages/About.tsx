import { Target, Eye, Award, Shield, Users2, Globe } from 'lucide-react';

export function About() {
  const certifications = [
    'ISO 9001:2015 Quality Management',
    'ISO 14001:2015 Environmental Management',
    'OHSAS 18001 Health & Safety',
    'Professional Engineering Licenses',
  ];

  const strengths = [
    {
      icon: Users2,
      title: 'Expert Team',
      description:
        'Our multidisciplinary team brings decades of combined experience across various engineering sectors.',
    },
    {
      icon: Globe,
      title: 'Global Reach',
      description:
        'We serve clients worldwide while maintaining strong local presence and understanding of regional requirements.',
    },
    {
      icon: Shield,
      title: 'Quality Assurance',
      description:
        'Rigorous quality control processes ensure every project meets the highest industry standards.',
    },
  ];

  return (
    <div className="bg-white">
      <section className="relative bg-gradient-to-br from-blue-900 to-blue-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About Quantest</h1>
            <p className="text-xl text-blue-100 leading-relaxed">
              A trusted partner in engineering excellence, delivering innovative solutions that drive industry success.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Who We Are</h2>
              <div className="prose prose-lg text-gray-600 space-y-4">
                <p className="leading-relaxed">
                  Quantest Engineering Consultant is a leading provider of comprehensive engineering services, established with the vision of delivering technical excellence across diverse industries. Our commitment to innovation, quality, and client satisfaction has positioned us as a trusted partner for organizations seeking superior engineering solutions.
                </p>
                <p className="leading-relaxed">
                  With a team of highly qualified engineers and consultants, we bring together expertise in mechanical, electrical, civil, and industrial engineering disciplines. Our integrated approach enables us to tackle complex challenges and deliver solutions that exceed expectations.
                </p>
                <p className="leading-relaxed">
                  We pride ourselves on building long-term relationships with our clients, understanding their unique needs, and providing customized solutions that drive measurable results. From initial concept through final implementation, we remain dedicated to project success.
                </p>
              </div>
            </div>

            <div className="space-y-8">
              <div className="bg-blue-50 p-8 rounded-2xl border-l-4 border-blue-600">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-600 p-3 rounded-lg">
                    <Target className="h-8 w-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">Our Mission</h3>
                    <p className="text-gray-700 leading-relaxed">
                      To deliver innovative, reliable, and sustainable engineering solutions that empower our clients to achieve operational excellence and competitive advantage in their respective industries.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 p-8 rounded-2xl border-l-4 border-green-600">
                <div className="flex items-start space-x-4">
                  <div className="bg-green-600 p-3 rounded-lg">
                    <Eye className="h-8 w-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">Our Vision</h3>
                    <p className="text-gray-700 leading-relaxed">
                      To be recognized globally as the premier engineering consultancy, renowned for technical excellence, innovation, and unwavering commitment to client success and sustainable development.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Core Values
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="bg-blue-100 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                <Award className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Excellence</h3>
              <p className="text-gray-600 leading-relaxed">
                We pursue the highest standards in every aspect of our work, continuously improving our processes and capabilities to deliver exceptional results.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="bg-blue-100 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                <Shield className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Integrity</h3>
              <p className="text-gray-600 leading-relaxed">
                We conduct business with honesty, transparency, and ethical practices, building trust through consistent and reliable performance.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="bg-blue-100 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                <Users2 className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Collaboration</h3>
              <p className="text-gray-600 leading-relaxed">
                We believe in the power of teamwork, working closely with clients and partners to achieve shared objectives and mutual success.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="bg-blue-100 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                <Target className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Innovation</h3>
              <p className="text-gray-600 leading-relaxed">
                We embrace new technologies and methodologies, constantly seeking creative solutions to complex engineering challenges.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="bg-blue-100 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                <Globe className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Sustainability</h3>
              <p className="text-gray-600 leading-relaxed">
                We are committed to environmental responsibility, developing solutions that minimize ecological impact and promote long-term sustainability.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="bg-blue-100 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                <Eye className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Safety</h3>
              <p className="text-gray-600 leading-relaxed">
                We prioritize the safety of our team, clients, and communities, implementing comprehensive safety protocols in all our operations.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Quantest?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              What sets us apart in the engineering consultancy landscape
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {strengths.map((strength, index) => (
              <div
                key={index}
                className="text-center p-8"
              >
                <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <strength.icon className="h-10 w-10 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{strength.title}</h3>
                <p className="text-gray-600 leading-relaxed">{strength.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Certifications & Standards
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12">
              Our commitment to quality is validated by industry-recognized certifications
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {certifications.map((cert, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-lg shadow-md border-l-4 border-blue-600 hover:shadow-lg transition-shadow"
              >
                <div className="flex items-center space-x-3">
                  <Award className="h-6 w-6 text-blue-600 flex-shrink-0" />
                  <p className="font-semibold text-gray-900">{cert}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
